package com.hts.sss.controller;

import com.hts.sss.pojo.Resume;
import com.hts.sss.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/resume")
public class ResumeController {

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private ResumeService resumeService;

    @RequestMapping("/getBaseInfo")
    @ResponseBody
    public String getBaseInfo() {
        int localPort = request.getLocalPort();
        String id = request.getSession().getId();
        return localPort + "*" + id;
    }

    @RequestMapping("/toList")
    private String toList() {
        return "/resume/resumeList";
    }

    @RequestMapping("/toEdit")
    private String toEdit(Model model, Long id) {
        model.addAttribute("id", id);
        return "/resume/resumeEdit";
    }

    /**
     * 列表
     *
     * @return
     */
    @RequestMapping("/list")
    @ResponseBody
    public List<Resume> list() {
        return resumeService.list();
    }

    /**
     * 删除
     *
     * @param id
     * @return
     */
    @RequestMapping("/del")
    @ResponseBody
    public int del(Long id) {
        return resumeService.del(id);
    }

    /**
     * 查找详情
     *
     * @param id
     * @return
     */
    @RequestMapping("/findDetail")
    @ResponseBody
    public Resume findDetail(Long id) {
        return resumeService.findDetail(id);
    }

    /**
     * 保存
     *
     * @param resume
     * @return
     */
    @RequestMapping("/save")
    @ResponseBody
    public int save(@RequestBody Resume resume) {
        return resumeService.save(resume);
    }
}
