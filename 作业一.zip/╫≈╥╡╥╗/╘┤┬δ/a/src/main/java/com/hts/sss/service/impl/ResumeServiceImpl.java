package com.hts.sss.service.impl;

import com.hts.sss.dao.ResumeDao;
import com.hts.sss.pojo.Resume;
import com.hts.sss.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ResumeServiceImpl implements ResumeService {

    @Autowired
    private ResumeDao resumeDao;

    @Override
    public List<Resume> list() {
        return resumeDao.findAll();
    }

    @Override
    public int del(Long id) {
        resumeDao.deleteById(id);
        return 1;
    }

    @Override
    public Resume findDetail(Long id) {
        Optional<Resume> byId = resumeDao.findById(id);
        return byId.get();
    }

    @Override
    public int save(Resume resume) {
        Resume save = resumeDao.save(resume);
        return 1;
    }
}
