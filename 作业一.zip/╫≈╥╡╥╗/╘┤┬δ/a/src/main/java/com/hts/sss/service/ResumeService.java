
package com.hts.sss.service;

import com.hts.sss.pojo.Resume;

import java.util.List;

public interface ResumeService {

    List<Resume> list();

    int del(Long id);

    Resume findDetail(Long id);

    int save(Resume resume);
}
