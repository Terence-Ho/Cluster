package com.hts.sss.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {



    /**
     * 去登录页面
     *
     * @return
     */
    @RequestMapping("/toLogin")
    private String toLogin() {
        return "/user/login";
    }

    /**
     * 去首页
     *
     * @return
     */
    @RequestMapping("/toIndex")
    private String toIndex() {
        return "/user/index";
    }

    /**
     * 登录接口
     *
     * @param username
     * @param password
     * @param session
     * @return
     */
    @RequestMapping("/login")
    @ResponseBody
    public String login(String username, String password, HttpSession session) {
        if ("admin".equals(username) && "admin".equals(password)) {
            System.out.println("合法用户");
            session.setAttribute("username", username + System.currentTimeMillis());
//            return "redirect:/user/toIndex";
            return "1";
        } else {
            // 非法用户返回登录页面
            System.out.println("非法，跳转");
            return "0";
//            return "redirect:/user/toLogin";
        }
    }
}
